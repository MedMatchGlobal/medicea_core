export default {
  "Cardiology": "心脏科",
  "Endocrinology": "内分泌科",
  "Respiratory": "呼吸科",
  "Neurology": "神经科",
  "Psychiatry": "精神科",
  "Dermatology": "皮肤科",
  "Gastroenterology": "消化科",
  "Infectious Disease": "感染科",
  "Rheumatology": "风湿科",
  "Urology": "泌尿科",
  "Gynecology": "妇科",
  "Ophthalmology": "眼科",
  "ENT": "耳鼻喉科",
  "Hematology": "血液科",
  "Allergy/Immunology": "过敏与免疫科",
  "General / Other": "综合 / 其他"
};
