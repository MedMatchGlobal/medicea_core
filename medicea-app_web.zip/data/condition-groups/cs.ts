export default {
  "Cardiology": "Kardiologie",
  "Endocrinology": "Endokrinologie",
  "Respiratory": "Dýchací systém",
  "Neurology": "Neurologie",
  "Psychiatry": "Psychiatrie",
  "Dermatology": "Dermatologie",
  "Gastroenterology": "Gastroenterologie",
  "Infectious Disease": "Infekční nemoci",
  "Rheumatology": "Revmatologie",
  "Urology": "Urologie",
  "Gynecology": "Gynekologie",
  "Ophthalmology": "Oftalmologie",
  "ENT": "ORL (ušní-nosní-krční)",
  "Hematology": "Hematologie",
  "Allergy/Immunology": "Alergologie a Imunologie",
  "General / Other": "Obecné / Ostatní"
};
