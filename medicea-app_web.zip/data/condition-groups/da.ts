export default {
  "Cardiology": "Kardiologi",
  "Endocrinology": "Endokrinologi",
  "Respiratory": "Respirationssystemet",
  "Neurology": "Neurologi",
  "Psychiatry": "Psykiatri",
  "Dermatology": "Dermatologi",
  "Gastroenterology": "Gastroenterologi",
  "Infectious Disease": "Infektionssygdomme",
  "Rheumatology": "Reumatologi",
  "Urology": "Urologi",
  "Gynecology": "Gynækologi",
  "Ophthalmology": "Oftalmologi",
  "ENT": "ØNH (øre-næse-hals)",
  "Hematology": "Hæmatologi",
  "Allergy/Immunology": "Allergi og Immunologi",
  "General / Other": "Generelt / Andet"
};
