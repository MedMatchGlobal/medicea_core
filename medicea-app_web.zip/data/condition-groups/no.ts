export default {
  "Cardiology": "Kardiologi",
  "Endocrinology": "Endokrinologi",
  "Respiratory": "Respirasjonssystemet",
  "Neurology": "Nevrologi",
  "Psychiatry": "Psykiatri",
  "Dermatology": "Dermatologi",
  "Gastroenterology": "Gastroenterologi",
  "Infectious Disease": "Infeksjonssykdommer",
  "Rheumatology": "Revmatologi",
  "Urology": "Urologi",
  "Gynecology": "Gynekologi",
  "Ophthalmology": "Øyelege (oftalmologi)",
  "ENT": "ØNH (øre-nese-hals)",
  "Hematology": "Hematologi",
  "Allergy/Immunology": "Allergi og Immunologi",
  "General / Other": "Generelt / Annet"
};
