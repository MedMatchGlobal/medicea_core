export default {
  "Cardiology": "Kardiologia",
  "Endocrinology": "Endokrynologia",
  "Respiratory": "Układ oddechowy",
  "Neurology": "Neurologia",
  "Psychiatry": "Psychiatria",
  "Dermatology": "Dermatologia",
  "Gastroenterology": "Gastroenterologia",
  "Infectious Disease": "Choroby zakaźne",
  "Rheumatology": "Reumatologia",
  "Urology": "Urologia",
  "Gynecology": "Ginekologia",
  "Ophthalmology": "Okulistyka",
  "ENT": "Laryngologia (ENT)",
  "Hematology": "Hematologia",
  "Allergy/Immunology": "Alergologia i Immunologia",
  "General / Other": "Ogólne / Inne"
};
