export default {
  "Cardiology": "Kardiologie",
  "Endocrinology": "Endokrinologie",
  "Respiratory": "Respiratoriese stelsel",
  "Neurology": "Neurologie",
  "Psychiatry": "Psigiatrie",
  "Dermatology": "Dermatologie",
  "Gastroenterology": "Gastro-enterologie",
  "Infectious Disease": "Afskeibare siektes",
  "Rheumatology": "Reumatologie",
  "Urology": "Urologie",
  "Gynecology": "Ginekologie",
  "Ophthalmology": "Oftalmologie",
  "ENT": "Oor-neus-en-keel (ONK)",
  "Hematology": "Hematologie",
  "Allergy/Immunology": "Allergie en Immunologie",
  "General / Other": "Algemeen / Ander"
};
