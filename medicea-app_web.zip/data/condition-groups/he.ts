export default {
  "Cardiology": "קרדיולוגיה",
  "Endocrinology": "אנדוקרינולוגיה",
  "Respiratory": "מערכת הנשימה",
  "Neurology": "נוירולוגיה",
  "Psychiatry": "פסיכיאטריה",
  "Dermatology": "דרמטולוגיה",
  "Gastroenterology": "גסטרואנטרולוגיה",
  "Infectious Disease": "מחלות זיהומיות",
  "Rheumatology": "ראומטולוגיה",
  "Urology": "אורולוגיה",
  "Gynecology": "גינקולוגיה",
  "Ophthalmology": "רפואת עיניים",
  "ENT": "אא\"ג (אף-אוזן-גרון)",
  "Hematology": "המטולוגיה",
  "Allergy/Immunology": "אלרגיה ואימונולוגיה",
  "General / Other": "כללי / אחר"
};
