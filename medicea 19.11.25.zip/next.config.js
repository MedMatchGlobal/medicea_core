/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // DO NOT include experimental.appDir here
};

module.exports = nextConfig;
