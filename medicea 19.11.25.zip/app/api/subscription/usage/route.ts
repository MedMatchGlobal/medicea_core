// app/api/subscription/usage/route.ts
import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

const FREE_EQUIVALENT_LIMIT = 2;
const FREE_LEAFLET_LIMIT = 2;

export async function POST(req: NextRequest) {
  try {
    const deviceIdHeader = req.headers.get("x-medicea-device-id");
    const { feature } = (await req.json()) as {
      feature: "EQUIVALENT_SEARCH" | "LEAFLET";
    };

    if (!feature) {
      return NextResponse.json(
        { error: "Missing feature type" },
        { status: 400 }
      );
    }

    if (!deviceIdHeader) {
      return NextResponse.json(
        { error: "Missing device id" },
        { status: 400 }
      );
    }

    const device = await prisma.device.upsert({
      where: { deviceId: deviceIdHeader },
      update: {},
      create: { deviceId: deviceIdHeader, label: null },
    });

    if (device.isPremium) {
      await prisma.usageLog.create({
        data: {
          deviceId: device.id,
          feature,
        },
      });
      return NextResponse.json({ allowed: true, status: "PREMIUM" });
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const count = await prisma.usageLog.count({
      where: {
        deviceId: device.id,
        feature,
        createdAt: { gte: startOfMonth, lt: endOfMonth },
      },
    });

    const limit =
      feature === "EQUIVALENT_SEARCH"
        ? FREE_EQUIVALENT_LIMIT
        : FREE_LEAFLET_LIMIT;

    if (count >= limit) {
      return NextResponse.json(
        { allowed: false, status: "FREE", reason: "LIMIT_REACHED" },
        { status: 403 }
      );
    }

    await prisma.usageLog.create({
      data: {
        deviceId: device.id,
        feature,
      },
    });

    return NextResponse.json({ allowed: true, status: "FREE" });
  } catch (error) {
    console.error("Error in /api/subscription/usage", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
