// app/lib/usageTracker.ts

type Feature = "equivalentSearch" | "leaflet";

const STORAGE_KEY = "medicea-usage-v1";
const DEVICE_ID_KEY = "medicea-device-id";
const PREMIUM_DEVICE_TOKEN_KEY = "medicea-premium-device-token";

interface UsageState {
  month: string;
  equivalentSearchCount: number;
  leafletCount: number;
}

function getCurrentMonthKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export function getDeviceId(): string {
  if (typeof window === "undefined") return "";
  let id = window.localStorage.getItem(DEVICE_ID_KEY);
  if (!id) {
    if (crypto.randomUUID) {
      id = crypto.randomUUID();
    } else {
      id = Math.random().toString(36).slice(2) + Date.now().toString(36);
    }
    window.localStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}

export function isPremiumDeviceLocal(): boolean {
  if (typeof window === "undefined") return false;
  const token = window.localStorage.getItem(PREMIUM_DEVICE_TOKEN_KEY);
  return !!token;
}

export function activatePremiumDeviceLocal(token: string): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PREMIUM_DEVICE_TOKEN_KEY, token);
}

function readUsage(): UsageState {
  if (typeof window === "undefined") {
    return {
      month: getCurrentMonthKey(),
      equivalentSearchCount: 0,
      leafletCount: 0,
    };
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return {
        month: getCurrentMonthKey(),
        equivalentSearchCount: 0,
        leafletCount: 0,
      };
    }
    const parsed = JSON.parse(raw) as UsageState;
    if (parsed.month !== getCurrentMonthKey()) {
      return {
        month: getCurrentMonthKey(),
        equivalentSearchCount: 0,
        leafletCount: 0,
      };
    }
    return parsed;
  } catch {
    return {
      month: getCurrentMonthKey(),
      equivalentSearchCount: 0,
      leafletCount: 0,
    };
  }
}

function writeUsage(next: UsageState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}

export function hasFreeQuota(feature: Feature): boolean {
  if (isPremiumDeviceLocal()) return true;

  const usage = readUsage();
  const limit = feature === "equivalentSearch" ? 2 : 2;
  const count =
    feature === "equivalentSearch"
      ? usage.equivalentSearchCount
      : usage.leafletCount;

  return count < limit;
}

export function incrementUsage(feature: Feature): void {
  if (isPremiumDeviceLocal()) return;

  const usage = readUsage();
  if (feature === "equivalentSearch") {
    usage.equivalentSearchCount += 1;
  } else {
    usage.leafletCount += 1;
  }
  writeUsage(usage);
}

