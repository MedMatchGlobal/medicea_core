export type SubscriptionStatus = "FREE" | "PREMIUM" | "UNKNOWN";

export interface SubscriptionInfo {
  status: SubscriptionStatus;
  isLoggedIn: boolean;
  equivalentUsed: number;
  equivalentLimit: number;
  leafletUsed: number;
  leafletLimit: number;
}

export async function fetchSubscriptionInfo(): Promise<SubscriptionInfo> {
  try {
    const res = await fetch("/api/subscription", {
      method: "GET",
      credentials: "include",
    });

    if (!res.ok) {
      throw new Error("Failed to fetch subscription info");
    }

    const data = (await res.json()) as SubscriptionInfo;
    return data;
  } catch (error) {
    console.error("fetchSubscriptionInfo error:", error);
    return {
      status: "UNKNOWN",
      isLoggedIn: false,
      equivalentUsed: 0,
      equivalentLimit: 2,
      leafletUsed: 0,
      leafletLimit: 2,
    };
  }
}

export async function registerUsage(
  feature: "EQUIVALENT_SEARCH" | "LEAFLET"
): Promise<{ allowed: boolean; status: SubscriptionStatus }> {
  try {
    const res = await fetch("/api/subscription/usage", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ feature }),
    });

    if (!res.ok) {
      // If 403 due to limit exceeded
      if (res.status === 403) {
        const data = await res.json();
        return {
          allowed: false,
          status: data.status ?? "FREE",
        };
      }
      throw new Error("Usage registration failed");
    }

    const data = await res.json();
    return {
      allowed: data.allowed,
      status: data.status ?? "UNKNOWN",
    };
  } catch (error) {
    console.error("registerUsage error:", error);
    // fallback: deny and show paywall
    return { allowed: false, status: "UNKNOWN" };
  }
}
