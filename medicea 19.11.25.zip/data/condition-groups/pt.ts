export default {
  "Cardiology": "Cardiologia",
  "Endocrinology": "Endocrinologia",
  "Respiratory": "Sistema respiratório",
  "Neurology": "Neurologia",
  "Psychiatry": "Psiquiatria",
  "Dermatology": "Dermatologia",
  "Gastroenterology": "Gastroenterologia",
  "Infectious Disease": "Doenças infecciosas",
  "Rheumatology": "Reumatologia",
  "Urology": "Urologia",
  "Gynecology": "Ginecologia",
  "Ophthalmology": "Oftalmologia",
  "ENT": "Otorrinolaringologia (ORL)",
  "Hematology": "Hematologia",
  "Allergy/Immunology": "Alergia e Imunologia",
  "General / Other": "Geral / Outros"
};
