export default {
  "Cardiology": "Cardiologia",
  "Endocrinology": "Endocrinologia",
  "Respiratory": "Apparato respiratorio",
  "Neurology": "Neurologia",
  "Psychiatry": "Psichiatria",
  "Dermatology": "Dermatologia",
  "Gastroenterology": "Gastroenterologia",
  "Infectious Disease": "Malattie infettive",
  "Rheumatology": "Reumatologia",
  "Urology": "Urologia",
  "Gynecology": "Ginecologia",
  "Ophthalmology": "Oftalmologia",
  "ENT": "Otorinolaringoiatria (ORL)",
  "Hematology": "Ematologia",
  "Allergy/Immunology": "Allergologia e Immunologia",
  "General / Other": "Generale / Altro"
};
