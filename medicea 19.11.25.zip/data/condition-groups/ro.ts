export default {
  "Cardiology": "Cardiologie",
  "Endocrinology": "Endocrinologie",
  "Respiratory": "Sistemul respirator",
  "Neurology": "Neurologie",
  "Psychiatry": "Psihiatrie",
  "Dermatology": "Dermatologie",
  "Gastroenterology": "Gastroenterologie",
  "Infectious Disease": "Boli infecțioase",
  "Rheumatology": "Reumatologie",
  "Urology": "Urologie",
  "Gynecology": "Ginecologie",
  "Ophthalmology": "Oftalmologie",
  "ENT": "ORL (otorinolaringologie)",
  "Hematology": "Hematologie",
  "Allergy/Immunology": "Alergologie și Imunologie",
  "General / Other": "General / Altele"
};
