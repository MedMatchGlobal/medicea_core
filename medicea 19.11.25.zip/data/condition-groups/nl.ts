export default {
  "Cardiology": "Cardiologie",
  "Endocrinology": "Endocrinologie",
  "Respiratory": "Ademhalingsstelsel",
  "Neurology": "Neurologie",
  "Psychiatry": "Psychiatrie",
  "Dermatology": "Dermatologie",
  "Gastroenterology": "Gastro-enterologie",
  "Infectious Disease": "Infectieziekten",
  "Rheumatology": "Reumatologie",
  "Urology": "Urologie",
  "Gynecology": "Gynaecologie",
  "Ophthalmology": "Oogheelkunde",
  "ENT": "KNO (Keel-Neus-Oorheelkunde)",
  "Hematology": "Hematologie",
  "Allergy/Immunology": "Allergologie en Immunologie",
  "General / Other": "Algemeen / Overig"
};
