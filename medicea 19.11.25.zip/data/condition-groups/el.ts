export default {
  "Cardiology": "Καρδιολογία",
  "Endocrinology": "Ενδοκρινολογία",
  "Respiratory": "Αναπνευστικό σύστημα",
  "Neurology": "Νευρολογία",
  "Psychiatry": "Ψυχιατρική",
  "Dermatology": "Δερματολογία",
  "Gastroenterology": "Γαστρεντερολογία",
  "Infectious Disease": "Λοιμώδη νοσήματα",
  "Rheumatology": "Ρευματολογία",
  "Urology": "Ουρολογία",
  "Gynecology": "Γυναικολογία",
  "Ophthalmology": "Οφθαλμολογία",
  "ENT": "ΩΡΛ (Ωτορινολαρυγγολογία)",
  "Hematology": "Αιματολογία",
  "Allergy/Immunology": "Αλλεργιολογία και Ανοσολογία",
  "General / Other": "Γενικά / Άλλα"
};
