export default {
  "Cardiology": "Кардиология",
  "Endocrinology": "Эндокринология",
  "Respiratory": "Дыхательная система",
  "Neurology": "Неврология",
  "Psychiatry": "Психиатрия",
  "Dermatology": "Дерматология",
  "Gastroenterology": "Гастроэнтерология",
  "Infectious Disease": "Инфекционные болезни",
  "Rheumatology": "Ревматология",
  "Urology": "Урология",
  "Gynecology": "Гинекология",
  "Ophthalmology": "Офтальмология",
  "ENT": "ЛОР (отоларингология)",
  "Hematology": "Гематология",
  "Allergy/Immunology": "Аллергология и Иммунология",
  "General / Other": "Общее / Другое"
};
