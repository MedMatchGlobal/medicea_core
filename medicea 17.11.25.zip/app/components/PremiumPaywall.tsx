
type Reason = 'equivalentSearch' | 'leaflet' | 'pets' | 'generics' | 'triage';

type Props = {
  visible: boolean;
  reason?: Reason;
  onClose: () => void;
  onUpgrade: () => void;
};

const reasonMessages: Record<Reason, string> = {
  equivalentSearch:
    'You have reached your 2 free equivalent searches for this month. Upgrade to medicea Premium for unlimited international equivalence searches.',
  leaflet:
    'You have reached your 2 free leaflet views for this month. Upgrade to medicea Premium for unlimited leaflet access.',
  pets:
    'Meds 4 Pets is a Premium-only feature. Upgrade to medicea Premium to unlock veterinary medicines equivalence.',
  generics:
    'Generic search is a Premium-only feature. Upgrade to medicea Premium to view closest generics and alternatives.',
  triage:
    'Symptoms Triage is a Premium-only feature. Upgrade to medicea Premium to unlock guided triage support.',
};

export default function PremiumPaywall({
  visible,
  reason,
  onClose,
  onUpgrade,
}: Props) {
  if (!visible) return null;

  const title = 'medicéa Premium required';
  const body =
    (reason && reasonMessages[reason]) ||
    'This feature is only available with a medicea Premium subscription.';

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0,0,0,0.35)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        padding: '1.5rem',
      }}
    >
      <div
        style={{
          maxWidth: 420,
          width: '100%',
          backgroundColor: '#ffffff',
          borderRadius: 16,
          padding: '20px 22px',
          boxShadow: '0 18px 40px rgba(0,0,0,0.22)',
        }}
      >
        <h2
          style={{
            fontSize: '1.25rem',
            fontWeight: 700,
            marginBottom: 8,
          }}
        >
          {title}
        </h2>
        <p style={{ fontSize: '0.95rem', marginBottom: 16 }}>{body}</p>

        <div
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
            gap: 8,
            marginTop: 6,
          }}
        >
          <button
            type="button"
            onClick={onClose}
            style={{
              padding: '8px 14px',
              borderRadius: 9999,
              border: '1px solid #d1d5db',
              background: '#f9fafb',
              cursor: 'pointer',
              fontSize: '0.9rem',
            }}
          >
            Maybe later
          </button>
          <button
            type="button"
            onClick={onUpgrade}
            style={{
              padding: '8px 16px',
              borderRadius: 9999,
              border: 'none',
              background:
                'linear-gradient(135deg, #4f46e5 0%, #2563eb 50%, #0891b2 100%)',
              color: '#ffffff',
              cursor: 'pointer',
              fontSize: '0.9rem',
              fontWeight: 600,
            }}
          >
            Upgrade to Premium
          </button>
        </div>
      </div>
    </div>
  );
}
