'use client';

type Feature = 'equivalentSearch' | 'leaflet';

type UsageRecord = {
  month: string; // YYYY-MM
  counts: Partial<Record<Feature, number>>;
};

const STORAGE_KEY = 'medicea_usage_v1';

function getCurrentMonth(): string {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  return `${d.getFullYear()}-${m}`;
}

function safeParse(raw: string | null): UsageRecord | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as UsageRecord;
    if (!parsed || typeof parsed !== 'object') return null;
    if (typeof parsed.month !== 'string') return null;
    if (!parsed.counts || typeof parsed.counts !== 'object') {
      parsed.counts = {};
    }
    return parsed;
  } catch {
    return null;
  }
}

export function getUsage(): UsageRecord {
  if (typeof window === 'undefined') {
    return { month: getCurrentMonth(), counts: {} };
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  const parsed = safeParse(raw);
  const currentMonth = getCurrentMonth();

  if (!parsed || parsed.month !== currentMonth) {
    const fresh: UsageRecord = { month: currentMonth, counts: {} };
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    return fresh;
  }

  return parsed;
}

export function incrementUsage(feature: Feature): UsageRecord {
  if (typeof window === 'undefined') {
    return { month: getCurrentMonth(), counts: {} };
  }

  const current = getUsage();
  const month = getCurrentMonth();

  if (current.month !== month) {
    current.month = month;
    current.counts = {};
  }

  const prev = current.counts[feature] ?? 0;
  current.counts[feature] = prev + 1;

  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
  return current;
}

export function hasFreeQuota(feature: Feature): boolean {
  const usage = getUsage();
  const limit = feature === 'equivalentSearch' ? 2 : 2; // 2 free equivalent searches, 2 free leaflets
  const used = usage.counts[feature] ?? 0;
  return used < limit;
}

export function remainingQuota(feature: Feature): number {
  const usage = getUsage();
  const limit = feature === 'equivalentSearch' ? 2 : 2;
  const used = usage.counts[feature] ?? 0;
  return Math.max(limit - used, 0);
}
