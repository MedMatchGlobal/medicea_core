// app/types/billing.ts
export type SubscriptionStatus = "FREE" | "PREMIUM" | "UNKNOWN";
