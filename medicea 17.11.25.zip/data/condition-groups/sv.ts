export default {
  "Cardiology": "Kardiologi",
  "Endocrinology": "Endokrinologi",
  "Respiratory": "Andningsorganen",
  "Neurology": "Neurologi",
  "Psychiatry": "Psykiatri",
  "Dermatology": "Dermatologi",
  "Gastroenterology": "Gastroenterologi",
  "Infectious Disease": "Infektionssjukdomar",
  "Rheumatology": "Reumatologi",
  "Urology": "Urologi",
  "Gynecology": "Gynekologi",
  "Ophthalmology": "Oftalmologi",
  "ENT": "ÖNH (öron-näsa-hals)",
  "Hematology": "Hematologi",
  "Allergy/Immunology": "Allergi och Immunologi",
  "General / Other": "Allmänt / Övrigt"
};
