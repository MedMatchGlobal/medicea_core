export default {
  "Cardiology": "हृदय रोग",
  "Endocrinology": "अंतःस्राव विज्ञान",
  "Respiratory": "श्वसन तंत्र",
  "Neurology": "तंत्रिका विज्ञान",
  "Psychiatry": "मनोचिकित्सा",
  "Dermatology": "चर्म रोग",
  "Gastroenterology": "आंत्रविज्ञान (गैस्ट्रोएंटरोलॉजी)",
  "Infectious Disease": "संक्रामक रोग",
  "Rheumatology": "रूमेटोलॉजी",
  "Urology": "मूत्रविज्ञान",
  "Gynecology": "स्त्री रोग",
  "Ophthalmology": "नेत्र विज्ञान",
  "ENT": "ईएनटी (कान-नाक-गला)",
  "Hematology": "रक्त विज्ञान",
  "Allergy/Immunology": "एलर्जी व इम्यूनोलॉजी",
  "General / Other": "सामान्य / अन्य"
};
