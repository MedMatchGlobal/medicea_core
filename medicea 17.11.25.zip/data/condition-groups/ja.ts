export default {
  "Cardiology": "循環器内科",
  "Endocrinology": "内分泌科",
  "Respiratory": "呼吸器科",
  "Neurology": "神経内科",
  "Psychiatry": "精神科",
  "Dermatology": "皮膚科",
  "Gastroenterology": "消化器内科",
  "Infectious Disease": "感染症科",
  "Rheumatology": "リウマチ科",
  "Urology": "泌尿器科",
  "Gynecology": "婦人科",
  "Ophthalmology": "眼科",
  "ENT": "耳鼻咽喉科",
  "Hematology": "血液内科",
  "Allergy/Immunology": "アレルギー・免疫科",
  "General / Other": "一般 / その他"
};
