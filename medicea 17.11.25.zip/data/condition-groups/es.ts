export default {
  "Cardiology": "Cardiología",
  "Endocrinology": "Endocrinología",
  "Respiratory": "Aparato respiratorio",
  "Neurology": "Neurología",
  "Psychiatry": "Psiquiatría",
  "Dermatology": "Dermatología",
  "Gastroenterology": "Gastroenterología",
  "Infectious Disease": "Enfermedades infecciosas",
  "Rheumatology": "Reumatología",
  "Urology": "Urología",
  "Gynecology": "Ginecología",
  "Ophthalmology": "Oftalmología",
  "ENT": "Otorrinolaringología (ORL)",
  "Hematology": "Hematología",
  "Allergy/Immunology": "Alergia e Inmunología",
  "General / Other": "General / Otros"
};
