export default {
  "Cardiology": "Kardiyoloji",
  "Endocrinology": "Endokrinoloji",
  "Respiratory": "Solunum sistemi",
  "Neurology": "Nöroloji",
  "Psychiatry": "Psikiyatri",
  "Dermatology": "Dermatoloji",
  "Gastroenterology": "Gastroenteroloji",
  "Infectious Disease": "Enfeksiyon hastalıkları",
  "Rheumatology": "Romatoloji",
  "Urology": "Üroloji",
  "Gynecology": "Jinekoloji",
  "Ophthalmology": "Oftalmoloji",
  "ENT": "Kulak Burun Boğaz (KBB)",
  "Hematology": "Hematoloji",
  "Allergy/Immunology": "Alerji ve İmmünoloji",
  "General / Other": "Genel / Diğer"
};
