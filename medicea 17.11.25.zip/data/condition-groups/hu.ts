export default {
  "Cardiology": "Kardiológia",
  "Endocrinology": "Endokrinológia",
  "Respiratory": "Légzőrendszer",
  "Neurology": "Neurológia",
  "Psychiatry": "Pszichiátria",
  "Dermatology": "Bőrgyógyászat",
  "Gastroenterology": "Gasztroenterológia",
  "Infectious Disease": "Fertőző betegségek",
  "Rheumatology": "Reumatológia",
  "Urology": "Urológia",
  "Gynecology": "Nőgyógyászat",
  "Ophthalmology": "Szemészet",
  "ENT": "Fül-orr-gégészet",
  "Hematology": "Hematológia",
  "Allergy/Immunology": "Allergológia és Immunológia",
  "General / Other": "Általános / Egyéb"
};
