export default {
  "Cardiology": "Kardiologie",
  "Endocrinology": "Endokrinologie",
  "Respiratory": "Atemwegserkrankungen",
  "Neurology": "Neurologie",
  "Psychiatry": "Psychiatrie",
  "Dermatology": "Dermatologie",
  "Gastroenterology": "Gastroenterologie",
  "Infectious Disease": "Infektiologie",
  "Rheumatology": "Rheumatologie",
  "Urology": "Urologie",
  "Gynecology": "Gynäkologie",
  "Ophthalmology": "Ophthalmologie",
  "ENT": "HNO (Hals-Nasen-Ohren-Heilkunde)",
  "Hematology": "Hämatologie",
  "Allergy/Immunology": "Allergologie und Immunologie",
  "General / Other": "Allgemein / Sonstiges"
};
    