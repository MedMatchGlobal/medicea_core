export default {
  "Cardiology": "Cardiologie",
  "Endocrinology": "Endocrinologie",
  "Respiratory": "Appareil respiratoire",
  "Neurology": "Neurologie",
  "Psychiatry": "Psychiatrie",
  "Dermatology": "Dermatologie",
  "Gastroenterology": "Gastroentérologie",
  "Infectious Disease": "Maladies infectieuses",
  "Rheumatology": "Rhumatologie",
  "Urology": "Urologie",
  "Gynecology": "Gynécologie",
  "Ophthalmology": "Ophtalmologie",
  "ENT": "ORL (Oto-rhino-laryngologie)",
  "Hematology": "Hématologie",
  "Allergy/Immunology": "Allergologie et Immunologie",
  "General / Other": "Général / Autre"
};
