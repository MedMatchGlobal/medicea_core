export default {
  "Cardiology": "Cardiology",
  "Endocrinology": "Endocrinology",
  "Respiratory": "Respiratory",
  "Neurology": "Neurology",
  "Psychiatry": "Psychiatry",
  "Dermatology": "Dermatology",
  "Gastroenterology": "Gastroenterology",
  "Infectious Disease": "Infectious disease",
  "Rheumatology": "Rheumatology",
  "Urology": "Urology",
  "Gynecology": "Gynecology",
  "Ophthalmology": "Ophthalmology",
  "ENT": "ENT (Ear, Nose & Throat)",
  "Hematology": "Hematology",
  "Allergy/Immunology": "Allergy & Immunology",
  "General / Other": "General / Other"
};
    