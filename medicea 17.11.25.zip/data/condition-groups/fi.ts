export default {
  "Cardiology": "Kardiologia",
  "Endocrinology": "Endokrinologia",
  "Respiratory": "Hengityselimet",
  "Neurology": "Neurologia",
  "Psychiatry": "Psykiatria",
  "Dermatology": "Dermatologia",
  "Gastroenterology": "Gastroenterologia",
  "Infectious Disease": "Infektiotaudit",
  "Rheumatology": "Reumatologia",
  "Urology": "Urologia",
  "Gynecology": "Gynekologia",
  "Ophthalmology": "Oftalmologia",
  "ENT": "KNK (korva-nenä-kurkku)",
  "Hematology": "Hematologia",
  "Allergy/Immunology": "Allergologia ja Immunologia",
  "General / Other": "Yleinen / Muu"
};
